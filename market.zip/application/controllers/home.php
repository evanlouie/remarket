<?php

class Home_Controller extends Base_Controller {

	public function action_index()
	{
		echo "Home Page";
	}


}
