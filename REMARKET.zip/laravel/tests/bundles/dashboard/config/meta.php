<?php

return array(

	'bundle' => 'dashboard',

);